const LICENSE_URL = "https://gist.githubusercontent.com/amankhan007/d778baaddf84ddc97a775ff37a024a36/raw/license.json";

function generateDeviceId() {
  return 'dev-' + Math.random().toString(36).substring(2, 15);
}

async function getOrCreateDeviceId() {
  const result = await chrome.storage.local.get("device_id");
  if (result.device_id) return result.device_id;
  const newId = generateDeviceId();
  await chrome.storage.local.set({ device_id: newId });
  return newId;
}

async function validateLicenseKey(key) {
  const deviceId = await getOrCreateDeviceId();
  console.log("🔐 Validating key:", key);
  console.log("🖥️ Device ID:", deviceId);

  try {
    const response = await fetch(LICENSE_URL);
    const data = await response.json();
    console.log("📦 Licenses received:", data);
    const licenseEntry = data[key];
    console.log("🔍 License entry for key:", licenseEntry);
    if (!licenseEntry) return { valid: false };
    if (!licenseEntry.device_id || licenseEntry.device_id === deviceId) {
      return { valid: true };
    } else {
      return { valid: false, reason: "bound-to-another" };
    }
  } catch (err) {
    console.error("License check failed:", err);
    return { valid: false, reason: "network-error" };
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const saveBtn = document.getElementById("saveBtn");
  const runBtn = document.getElementById("runBtn");
  const statusEl = document.getElementById("status");
  const keyInput = document.getElementById("licenseKey");

  runBtn.disabled = true;
  runBtn.style.backgroundColor = "#aaa";

  function hideLicenseUI() {
    saveBtn.style.display = "none";
    keyInput.style.display = "none";
  }

  saveBtn.addEventListener("click", async () => {
    const key = keyInput.value.trim();
    if (!key) {
      statusEl.innerText = "Please enter your license key.";
      return;
    }

    statusEl.innerText = "Validating...";
    const result = await validateLicenseKey(key);

    if (result.valid) {
      await chrome.storage.local.set({ licenseKey: key });
      statusEl.innerText = "License accepted!";
      runBtn.disabled = false;
      runBtn.style.backgroundColor = "#4CAF50";
      hideLicenseUI();
    } else if (result.reason === "bound-to-another") {
      statusEl.innerText = " License used on another device.";
    } else {
      statusEl.innerText = "Invalid license key.";
    }
  });

  runBtn.addEventListener("click", async () => {
    const { licenseKey } = await chrome.storage.local.get("licenseKey");
    const result = await validateLicenseKey(licenseKey);

    if (!result.valid) {
      statusEl.innerText = "License invalid or expired.";
      runBtn.disabled = true;
      runBtn.style.backgroundColor = "#aaa";
      return;
    }

    // ✅ SET autoRun FLAG in localStorage
    chrome.scripting.executeScript({
      target: { tabId: (await chrome.tabs.query({ active: true, currentWindow: true }))[0].id },
      func: () => {
        localStorage.setItem("autoRun", "true");
      }
    });

    // ✅ Inject script
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const s = document.createElement('script');
        s.src = chrome.runtime.getURL('inject.js');
        document.documentElement.appendChild(s);
        s.onload = () => s.remove();
      }
    });

    statusEl.innerText = "Script injected & auto mode ON!";
  });

  // Auto check if already valid
  (async () => {
    const { licenseKey } = await chrome.storage.local.get("licenseKey");
    if (!licenseKey) return;
    const result = await validateLicenseKey(licenseKey);
    if (result.valid) {
      runBtn.disabled = false;
      runBtn.style.backgroundColor = "#4CAF50";
      hideLicenseUI();
    }
  })();
});
