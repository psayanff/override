(function persistentInjector() {
  console.log("🚀 Injected on:", window.location.href);

  // ✅ 1. Face Authentication Bypass
  (function () {
    console.log("🔓 Enhanced face authentication bypass activated");

    const waitForElements = setInterval(() => {
      if (
        typeof aware !== "undefined" &&
        document.querySelector("video") &&
        document.getElementById("message")
      ) {
        clearInterval(waitForElements);
        executeBypass();
      }
    }, 500);

    function executeBypass() {
      window.isGenuine = true;
      window.realFaceCount = 30;
      window.spoofFaceCount = 0;
      window.totalChecks = 40;
      window.smileCounter = 5;
      window.blinkCount = 5;
      window.eyesClosed = 0;
      window.matchCount = 1;

      const video = document.querySelector("video");
      let fakePhoto = null;

      const tempCanvas = document.createElement("canvas");
      const tempCtx = tempCanvas.getContext("2d");
      if (video && video.readyState >= 2) {
        tempCanvas.width = video.videoWidth || 300;
        tempCanvas.height = video.videoHeight || 300;
        tempCtx.drawImage(video, 0, 0, tempCanvas.width, tempCanvas.height);
        fakePhoto = tempCanvas.toDataURL("image/jpeg", 0.5);
        console.log("✅ Created fake photo from video");
      } else {
        tempCanvas.width = 300;
        tempCanvas.height = 300;
        tempCtx.fillStyle = "#ffffff";
        tempCtx.fillRect(0, 0, 300, 300);
        fakePhoto = tempCanvas.toDataURL("image/jpeg", 0.5);
        console.log("⚠️ Created blank photo as fallback");
      }

      window.returnObject = {
        isMatch: true,
        message: "Click on Proceed to validate your credentials",
        nextExp: "",
        photo: fakePhoto,
      };

      window.aware.match = function () {
        const result = window.returnObject;
        if (window.messageToShown)
          window.messageToShown.innerHTML = result.message;

        const btn1 = document.getElementById("capphto1");
        const btn0 = document.getElementById("capphto");
        if (btn1) btn1.disabled = false;
        if (btn0) btn0.disabled = true;

        const llappln = document.getElementById("llappln")?.value || "";
        const rtocode = document.getElementById("rtocode")?.value || "";

        $.ajax({
          type: "POST",
          url: "saveFaceAuthData.do",
          data: {
            applno: llappln,
            rtocode: rtocode,
            faceres: 1,
            CapPho: fakePhoto,
          },
          dataType: "json",
          success: () => console.log("✅ Auth data sent to server"),
        });

        return Promise.resolve(result);
      };

      window.insertfeceauth = () => true;

      document.getElementById("message").innerHTML =
        "Click on Proceed to validate your credentials";
      document.getElementById("capphto1").disabled = false;

      window.aware.match().then(() => {
        setTimeout(() => {
          const proceed = document.getElementById("capphto1");
          if (proceed && !proceed.disabled) {
            proceed.click();
            console.log("🖱️ Proceed clicked automatically");
          }
        }, 1000);
      });
    }
  })();

  // ✅ 2. Language + Checkbox + Continue (after 4s)
  setTimeout(() => {
    console.log("⏭️ Running autoPageActions...");
    function autoPageActions() {
      const interval = setInterval(() => {
        const langSelect = document.getElementById("language");
        if (langSelect && langSelect.value !== "ENGLISH") {
          const hindiOption = Array.from(langSelect.options).find(
            (opt) => opt.value === "ENGLISH"
          );
          if (hindiOption) {
            langSelect.value = "ENGLISH";
            langSelect.dispatchEvent(new Event("change", { bubbles: true }));
            console.log("[✓] Language set to Hindi");
          }
        }

        const checkbox1 = document.querySelector('input[name="disclaimer1"]');
        const checkbox2 = document.querySelector('input[name="disclaimer2"]');

        if (checkbox1 && !checkbox1.checked) {
          checkbox1.checked = true;
          checkbox1.dispatchEvent(new Event("click", { bubbles: true }));
          console.log("[✓] disclaimer1 checked");
        }

        if (checkbox2 && !checkbox2.checked) {
          checkbox2.checked = true;
          checkbox2.dispatchEvent(new Event("click", { bubbles: true }));
          console.log("[✓] disclaimer2 checked");
        }

        const continueBtn = document.getElementById("subm");
        if (continueBtn && !continueBtn.disabled) {
          continueBtn.click();
          console.log("[✓] CONTINUE clicked (id=subm)");
          clearInterval(interval);
          return;
        }

        const altBtn = document.querySelector(
          'input[type="submit"][value="CONTINUE"]:not([disabled])'
        );
        if (altBtn) {
          altBtn.click();
          console.log("[✓] CONTINUE clicked (no id)");
          clearInterval(interval);
        }
      }, 1000);
    }

    autoPageActions();
  }, 10);

  // ✅ 3. Exam iframe watcher (after 10s)
  setTimeout(() => {
    console.log("📘 Watching exam iframe");

    function injectExamScript() {
      const iframe = document.querySelector("iframe#stallexam");
      if (!iframe) return;

      function detectAndSubmit() {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        if (!iframeDoc) return;

        const scripts = Array.from(iframeDoc.getElementsByTagName("script"));
        let correctId = null;

        for (const script of scripts) {
          const code = script.textContent;
          const match = code.match(
            /document\.getElementById\("stallradio(\d+)"\)\.style\.visibility\s*=\s*['"]hidden['"]/
          );
          if (match) {
            correctId = `stallradio${match[1]}`;
            break;
          }
        }

        if (correctId) {
          const radio = iframeDoc.getElementById(correctId);
          if (radio) {
            radio.checked = true;
            console.log("✅ Selected correct:", correctId);

            const confirmBtn = iframeDoc.getElementById("confirmbut");
            if (confirmBtn) {
              confirmBtn.disabled = false;
              confirmBtn.click();
            }

            if (typeof iframeDoc.StallExam !== "undefined") {
              console.log("🚀 Submitting form...");
              iframeDoc.StallExam.submit();
            }
          }
        } else {
          console.log("❌ No correct answer found");
        }
      }

      iframe.addEventListener("load", () => {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        if (!iframeDoc) return;

        const observer = new MutationObserver(() => detectAndSubmit());
        observer.observe(iframeDoc.documentElement, {
          childList: true,
          subtree: true,
        });

        setTimeout(() => detectAndSubmit(), 10);
      });

      if (iframe.contentDocument?.readyState === "complete") {
        setTimeout(() => detectAndSubmit(), 10);
      }
    }

    const iframeChecker = setInterval(() => {
      const iframe = document.querySelector("iframe#stallexam");
      if (iframe) {
        injectExamScript();
        clearInterval(iframeChecker);
      }
    }, 50);
  }, 50);
})();
