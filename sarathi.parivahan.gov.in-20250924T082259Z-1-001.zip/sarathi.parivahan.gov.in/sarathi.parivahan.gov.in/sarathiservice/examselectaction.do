  <!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Insert title here</title>
<script type="text/javascript" src="js/jquery/jquery.js"></script>
	<script src="./proctoringMonitor/proctor.js"></script>
	
<style>
    video {
            width: 0px;
            height: 0px;
            border-radius: 10px;
    }
    .center{
    margin:auto;
    width:60%;
    border:5px solid #FFFFOO;
    padding:10px;
    }
   </style>

</head>
<body onload="procauth()" height="850px" width="100%">
    
      
<iframe src="" id="stallexam" name="stallexam" height="700px" width="100%" style="border: none"></iframe>
<div  id="stallexam"></div>
<center><h3 style='color: red'><strong id="message" ></strong></h3></center> 
  		<div class="center">
        <video id="video" width="100%" height="100%"  playsinline muted autoplay></video>
    
        
        

    </div>
</body>
<script type="text/javascript">

var pCount=0;
function prepareNextQs() {
	pCount=pCount+1;
	alert("pCOunt "+pCount);
	$("#lod").hide();
	
	//document.getElementById("pCount").value=pCount;

	$(document).ready(function() {
    			$.post("stallexamaction.do", function(data, status) {
			
    		  	$('#stallexam').html(data);
    		  	document.getElementById("timer").innerHTML = 30;
    		  	
    		  	return false;
    		  	});
    		});
}




function procauth() {
	
	 var authtype='Face'; 
	 var examdate='2025-09-20 13:01:37.322';
	 //alert("examdate--"+examdate);
	 /* let current = new Date();
	 let cDate = current.getFullYear() + '-' + (current.getMonth() + 1) + '-' + current.getDate();
	 let cTime = current.getHours() + ":" + current.getMinutes() + ":" + current.getSeconds();
	 let dateTime = cDate + ' ' + cTime;
	 console.log(dateTime); */
	 //alert("examdate--"+examdate);
	 //alert("authtype--"+authtype);
	 var slotId="1";
		if(authtype=="Procter"){
		var applno=3830919425; 
		var FaceAuthReq=null;
		aware.initializeProctor('video', 'message',"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCACoAIcDAREAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD6HA4rzZO6PRTT3E2+vNWrdTOXkNwA+APxot1FzdB+DiibT2KVo6mTr3iTSvD8HnahchSciONSN8h64AP9cD3ostgcktbnHw/GfwpM0iah9p0xUIAmuRH5eTwMsjNtGeMkAe9DSWlzP2kbnml7+0fp/hvxzqmneL5JLbSWmaHTbtEYxGRFHmRufbIIIBGWA7VPLqEqiTsivqv7Yfw5sFll/tliUGY7eK1eV39t3C5/ED3NDutLESkjE0n9vD4c3dyLPVNF1m0VmwLkwIYwPUqsjMPwBrVRutiFUOni/bI+CEkgi/4SC7UFc720+fbn04XNTy32K50b2mftC/DPXgkun6zG9u5wZjc242D1aPzPNH/fGfai1nsJ2fU7XRtf0bxHYrqeg6nb31o/CzQOGUn0PofY802r7EvQtjcGPPBo5WJeY9QAOFotcEAGPQGr23CwvA4pNpMBpJHXmh2YHWjOOK546LU7WnfQTkAk1V+onG+oAkCi5nrsgMijrxTUr7Dce7PMfivos/iKP7IutRaLZwxme5vlhWWZQOgUEZz3yCCMDGelS1d3BpNaHxB8Tbp/DaQaovj3WL9tUsxNZfadlxFNHu+aKQcFcEe+CMYBGarl51ZnPI8c1HxXf6lpwsrvU28qOVpIoMkohYDJAPfgD6AVvGCWxNzFe/kVEjJLKO/rQo6iuRSXis+RIBn0qm9bAJHfpG3MhLexp7gNa6Ysf33B7GnfXQTt1Or8EfFrxz4AvhfeEvElzp0pAV1Qho5VB+66MCrD6ilKCeoJrofTHwv/AG5bhitl8T9IikQEAX2nRbWHqXjJwf8AgOO/FZONveKTfU+ofBfxG8GfEGy/tDwhr9rqMQ++sTfPGfR1OCp9iKlW3KTOkIHpS62YDduenFO6egtRVXHU5p2t0C1zqVYBcswrCLb3R1SlbYCwZTzV6ESbY2MHBB5A70vUHEgu1R4yjg4PcEj+VK9tSbO58rftFfG/TPDU954X07U4Lq42bZB5uXs5FJwNwOcnoVOeCOR0Nwh7RakPQ+HfFGu33iC8aWTLHezYHQZNdEadkZtnOy24Em2RyG6/jTQDI4w7BMkjPTPJoAs3lvp64+zhx7saWjYroptCueCcetNEyl2GtE4OVJIot1IBJNvHQ02BahnIkAHQj86V21YqLZ2nw1+JWv8Aws8YWfinQ33GFgJoGciOeM/eRsdiO/Y4NTKF9SlI/TjwV400rx34X03xXosga21KBZlUsN0ZPBVsdwQR+FZOKNEzdUnGRwT1pXb0FccQSODg1aQXOok2/dxWKktrnZJaXEjI2HHaqcbhdNCeYp6sPwodhNXPAv2p/j/afDPw7L4X8P3JbxNqcP7vYf8Aj0hPBkY+p5CjnPJPHW4pSWhE5cmx+durJf3sxvrtQzTPncGzknqT3z9evNbRioq6OdtsiniFrbsUkLSE7QAO9VzNrQRly2Vw4ZimSep9Kl3bBq5BJYvAgcEjvmlzK9mJR6kasqNvnYkenXNUJrqxHuEfKxp8vQ1N0heg0rIoCr0+tUmpCasJHCpcmQ44ppIVhU8qJzk9uKdkBNb3Bdtj9O1LYFY+hP2Wv2hIPhnrJ8I+KnI8O6nMClwzEixmPBcj/nm3G70xu9ahrqWmffcV6k0CTWzRSI4DI6HcrKeQQRwR71lLVljxcyDgoBn0oTGdaW9sVyrZnodBoDbSR0x1zVwk5LQzdrkUkYVWbqapxS1G5X0R+Y3x6vrvU/iH4nvNQnkuLz+1Jo9zfwojlVAHYBVUAegFdVFXicc9zhLaCwjSO6uIyiYztzyx9xWrSsSdF4X8Lxa/O+p3UBS2TJ3EbVIqVZrQpRuyPxfBa2cMcOnWACRA7iq/eb1J9qXK2imuxwNx82TNkk9ugrC7T1JaZUa1jk4jUknp6Vad9SS9ZaDkHzlwD0PvUTqpIuFKT6Dp9FdBuC5U98cVKrNvQbptFO4tbeIhT941upJozaM+eIxnBQgnnPqKq/YzasLCCq5IyPWk7kkjMd6kGnFjufdf7GXxMk8R+Erjwbq10ZLvQ2Btix+ZrVug99rZH0Kis6miNEfSmIjng5NZqS2uM7AxDuSawSudzkHyj5Rx+HWqSWyJctNClqDOEYISDtPIpTkrWI5mmfml8RtMNn438QW2oqWmXUZywY5LZcsDx9a6qErR1Od6sf4T8DWviq6iW/t8wIwJCA9M9Mit2k1Y0hDm6Hu2ieBfDMKBZtOidFUBY2X5VH0pXSVkbqn1KHjTwH4WbTXjtNKihQZY7V5J+vWsajaRUKaTPnXXPBGmpduY432Bj3rjdW2xo8PFvUp22hadakeVbjjueah15tWGsPTjrYutDApCIi7MctjnPtSUrLcbi2NEMKIYY7ZWJ46VUZPYzlTuZd94cspD5jwgN1OOlbe1kkZSpJmVdaVbOPKZRxwKFVbd0ZyppGTc6N5Cny5Pl64NaKtzbmE4W2M0xKGGeO2fSumNmjLU9t/ZO1XUdK+MGlW9jgpepLbXKt/FEVz+jKp/Cs6mxUXd2P0IDDZz1rmuzWSsdqJVc/K3WhNdGdKlZaocfXgmrvbqJJdSjOQ5wV55FZy7k7ux8V/F34dyXHx7uzfkm0u7dNSYKuAwzs25+q81UKqQ6cFKVjstMtNK0eyW3sbGCBPRECj8hVqdtTr5VayIn8R6PYTNHeahGhAyF3Cqu7bieiOX8XeP9NktmitrhXzwcGsK02loaQUU9TyLWdVtpmYpIpDfjXG5XOhuLV0YizxmTBx9KLGD7krNbGM7cIfVqWo76XLOnmyjUPI6E/Wt7KCuYykhuqS2jodrJz6VTu7GTqJPU5O6mtlmOXHHGavW5nKUWPgtYLkDcAwPepcnFaEKKn1Keq+EmdWubA5KjcVreFSy1MpwutD2T9inQkuviZdarcf8w/T5No9WdlX+RNaTelzOK6H3QqL6E1iaNFiDVpVYAkj15rnbvqd9nszXttS80gFutaKV1oS4J7k0uG+YCnJmLST0PAvi/ZQTfEMahFPG8sWlRQOqsCUzLI2DzwenWsneOsToox967PKPGF7fsqwwTmOJOW7bqcKmup1TptrQ8M8bXOtySN5F0oY9NsnJH0rpjUi1ucE6MlrE8/u7/wAS25xJPMB6ZNOThMxlKrT3ZXi1fVy4LSO3sah04JDjWqdDoLG+vJYsspPvXJKFjthPmJ5ri7e3LRnkdqFHUbdkc9canq5zFGWxmuvlTWpxVKkyCObxFdP5YkZs/wC1itYKMdTnbk2XYtD1aU4uJkBPq/NOU4hGnUlsadhouoWMqzrcFlB+ZeoxWLnGSNY0pxep2Fgp43YwRyKygm3oXNPc+qv2Tvh5aeHvBQ8Sz24N1q7GYORyI84UfTjP411Wvoc6PdsjkKnTvUa32HcpNk59a4z073HwTPE3U4o1T0JKnxF8aHwd8Otf8SxkedYWErwH0lI2p/48RWqbjqRy6nzN8KtZl8U+Hf8AhI7q3EM2oSsZME/MyfIX5/vFSfxrRq60N6dluVvHumJKrRRzuxf+FTyKx9k29DpdRWsjmfCfgrW9OkeKfWLbRNLv0Y3E8MaS3LEHhGaQfLlckYyO3Wt7eyjqjlcXN6HifjHTNX0jxre6Xa6iNQtxcMtvcFlCyIT8pYj5QcdccA5ojGNVXRw1vaRdpGfqummx1NrJp4LkhQfPtjlN2ORnvQ0nozODZ6T8NfCqa1pF097DgwoWDEe1YNNs9SnG+5z+qxLaSTW0SjapxkCs+UVRNM4zWYZo3AhJ2sM5rtguhwVpX0M2FtVt7xY4UaTPTyxkmtlGLMLtHXa14e1vSNKsr+/nhaa6UMbY8OoPfisJSheyZactyzoDzOqxzBlHoxzWFdW2OilNy0ZvK2yQKnTPTNKm7PQqqla56V8Mv2kfGng/XNG0DX9Rt5/DiypZ/ZvssamGDON4dQGJUc8k5wa6b66HKo6XPtvajYZCGB6EHg07WZLM4lR1Fca1PRvfYbwTVNXegrnnn7QlyYvg34ktxybiCKBAf7zSoAfzpbbApanm3hCzg07SYtKs4vLjtgYEUdgpKg/U4z+NbU/3hqmkc74rsr6C7M7FgM5BrOovZ6m9OKmc3qviKae0NmZmBxtOKiVXn0CVNQVzzjUvC9zqF1vSdhk9WNXGV9LGMo8x2fgr4UWVwRLdObhxzgjgVfI5uxKoKCu9TuryDT/D+l3Nvp6IjLGVI96iouVbm9OLeyPB9Xn/ANLlMin5mrnQVoPcgXTYL6AowBz+hrSLcWckoKS1RXh0mXT5cpIy46Eda29poYex10LDwGc+ZKxkboM1Dq2LjSuNNtcq6+WCB6A0udtF8qSNHTllMyiXPXvThvqZTk2rFbWbZHu0micq9vcAP34rWVuYpaQsfpF4CS4XwR4fS8ctcDSrQSMect5S5q42aszkluO5Nc9knc7r20EYmk5MZ5X+0fIsnw0u9PWULcXM8IhXPLFWDcflVXezYRVzzvw5qUv2aOSZx5rEmRh/eJOf1rWHu7G1tCfxRcx3lmUV13AdTU1HGSt1Kptp3PLr2BUmd2xiuZxtqbSlzGJrWtx2SBYlXcB+VUm1sZyasdn8F9Y1TUrHUtYZ4xbxSrbRyyNhAcAvx3OCv510RbWrMqb9q7Hd+Nr7wofCZ+zzwyXjvlnUc+9Y4jka03O/DXUtdjxS/sdHmgMhmUu3PXpWEdDPESu7I51o7iwdmSPdF2PrWsWnI4qidtBIrhbv5jwfQ05voTHsxybFbaBz9Khxdi0OkYZAHekloKTWxasFHnDuR7VvSTbuzkqtdDNu43+1XhxnzJsqB7VVRXeglP3bH6YaBZvYaHpthMcvbWcMLH1KxgH+VawjZamDKrJ1NYp67HdJX2InBxxTab2E30PM/i54H1HxNFDqFhbrePbKQIDJsYEnqueD75I6CnZPoVTly3cjxDR5riC0e1nRkltpHidSeVYMQQfcGm4t7M2hJNXRca5E4Ku+AepzUNO9pF3scxq9s8rOLdCQOhHeqUbrlE5M43VPC97euTOSiMKj2TIupFux0D+zPDc+ix+I5bOCaTzQUb7rkAE4HsB+VXOCdrjjU9lHlRy99NLoMI05fEFzqELEnc+eD7ZpOmmtrErEOmrN3MabUPPiaOa8ljz91o2xV06Ol7HNPEuWxa0a+vGhFtcXwmQHgscmsqtKKdyqdRyVjSFsqyB42wtOMU1qJ1LaDnPlnOcjHWl7sdyVUtuQPPlhhuvpVOTa0Q3UXQ07GZV+boAOtNXWsjCT6Im8MaFr/iG4mvtL0LUr6JboIHt7OSVA/ZSVBGfarqyTSTCMkk0fo/pV1d3Wl2lzfWZtbmaBJJoCcmJyoLJ+B4rSFrGbKJz2asI2jud8lfYjdyOCaGovcm3LuV5nyu3FPQLxPlDxTnRPiB4i011MavevOqkdpMSA/wDj1a8qsOi7NozzdgSE5yD05qHa90dKLEOp2NhBJd3QBCqWA65NaQ1epnVbiro8z8U+OrnULhIrQ7BnGBxVyjE5ZVZMpTXmkRxxLdX0l1dHloo2wifVu59h+dJOO1iN9WZt9cadegxSCFdp42np+NTKyehpGz0ZlTR6Y6NCEGF6HPNOO2pjUtexnxpDCxENyy45Cv3/ABptJkehLH4hng2xscgcYJqORPYaqPqakWpfaUEoHUc1k4Wdy4y7irKVbO7IP6U1FdVqJtXLBvjHEUU5BGD61ryJENn2z+x9ay23wdt5XUhL3ULu4QkY437Px+4T+NXyqOxCd9j27OKmybKMZjjk1zSbZ26dGQSOc+1SpJ7lLYgd8nAPWrvfQzaPnP8AaO8Oz6Rr1n4rhiYw36CGV88CVBwPxX/0E1pSfQyT5Z3Z5SmqbiJFfIxz6VEnZnapaXTItS1NZbZkJPzA9KnnkmEveRx2neFo9aunF1dNDHnqp5rdSOR03JnX6T8NvAmlqtzqlzd3+AcokhUdOM4Oa05oNXZUKVnqYus6Z4Ourl0tNJeBQ52FHIO38+awlKTOxwptbGPPo/h6MARxSZ75cmri3azMJwppXsZV3pekuWAZ0HQc5qoyd9ThklfQyL6xsoAotSxPcsc5q7pbCsWbSQJAIwelRLV7AmWDOQAc/wD16TikBLAJbh0hhhd5JWCJGgyzMTgAD1NWrNEt2R+lXws8MHwX4B0Tw24US2VnGswXp5pG5/8Ax4mkkOKsjrQc803YpK5gvKM9TWF7HVMgkZueeKzfvCi+zIt4OKfITzGd418G2HxA8JXnhq9cIZkLwyf88pgDsb8D19s1cUlqhPVWZ8J6vZat4R1i50LW7dre5tpTFIh6ZHceo9DTb6sdOpbQZPeQuu12wan4lozVytqULfVPKnaJc7Sevap9n3Ye1TH6jeagI99lKy56YOafMkVzt7HI6pqHiGJsyTMAeRxWsYqSMZV5orwTaxMgd5SVPpVuGhi6spbkxaQAmRyMdealrXQi9zOuLvzDgHODVqC6g2S212qJhuTj6VNknoIl+07iCTtFaqN1YXMj6F/ZK+Fc/i7xOnjrVIR/ZOhygwBx/r7ocr+CcMffFNroQ3zOyPt9cKPlIxWfLfc0uSK2DjdVWGnY5wyHvXOttTbmbGEsST2NS4rZAmNZsfw0rJbAzP8AFPi3TfAXhDVPG+u+Yun6ZGMhMbppW4jiXPG5j+QBParjHmMqteFJe8z5X+Ivj/w3+0TZS33h/wAI3WjarpS83kk6yLdA5xGQFHIx1ycZrVQlDRmdKbq3aVrHhT3d3Bcm0vo3jkiO1g4x0pql1NHJjheNGBuI+bODmm4J6gpE9r4gMMTRhs446Zpezi9y1UdrGPrGsyXrguQQOlNpRVokSlfYz4tSljBVGwD69qlJtakjLnUGcEmTk1XKK6KLTsp4PerasRzWHRys8gJzmkopsOZm1pmnSXLq8wIjz3705aCSbPfPA/7R2p/CLwRD4Y0TwpZ3Yjlkn8+R25Zzk5VSOmAM0R97RsmftIfAj62+GXxJ0f4m+EbDxTpeE+1J++h35MMo4dD9Dmm12HSqqej3OuD98GoszVuxi21pdXxItoGkx1IGAPqTwKxhCU3yxRpOrGkrydkaEujW2mJu1bUUR9m/yYvmfHqfSvRhldV6zdjyqub04u1NXNHwv4bHiG5R/Ikt7Qv+734Lygck85wuMeh549a7qOVUnq2zza2b1notD40/bO+I03xA+LVv8F/Ds3keHfC03lzxxHCT3pUGWRsfeKDKD0Ib1rlxihTl7OOiR2ZdGpiZc89WZ3h7T7PQtLjsrGJY44wAAvH1P1ryr3dz6hQVNcqKviHw1omvwtcS28IuMfMSvLfj61om4kypqe55J4j8JyWRJgcjaeAe1OE0nqcsqbi7HF3YubVyp3D3Iq/MybsUJLt2OCOnXJoM+ZkAuWwdwznpTS0C7E3F+WBP60guy7Z6ddXRysRAP8TUm0txKLZuWGkR2xDsN7D16CpdW2xqoW1NJWEYwOuazUnLcofLctIApGRilvsB7j+yLqtyknifRobiRIkaC6iCsfkdtysR6Z2r+Vd2Ghzu1zxszk6MlNH0LB4y1+zYJ9p83aSpWQbhkcdetdU8LE5IZpUW+p2njfxmmg/8SvSb6OfWJWEKSgbobd24CxqOGb3wfavb5Y0o8sFY8eeJqVHeTbNhvCsXhHw8s+rzy6jdyN59y7n57qX0YnlY19O+PrVqm4xvJ3I9pdnbaFejSNJtdcvDvZdCnv2C92PlyMB+HFUrKN0iW/ePyIfxVdP8UtQ8S6vk3F9qNzNcFuzyOxb8ia+Vrvnk3I+1y20IRbPbre4W+tFngbgqDXHflPoE1NXRm3V60WVz+ZpKVyJaanMa5MLiM96rkvsYyqdjgtVtlkLKBU6rcykk9Uc5PpExYtHGSPXFXz2MJQGxaFM2N5UfU1SqdGTys17PQoEwxZc1LlYpRRqrawQD1I/Wob5tithjyjJVCAPQU7CuRkn1p2sBWu7gRKTuHA5NLmvpYD6T/ZU8J6jonh7VPFuqQmEayyfZlI5MKA4b8STj2Ga9XBUm05NHzWb4mMpKEWeqtHNHl5pA5eRmAxjaD2ru5TxVI9i+Cfgtb2+bxbq9uHW2Ba2Ei5w39/nv6GvRw8eeVzKT5UaPxa1oW+yBTjOSRW1aVtEZp63Ov8PBdX8EaYrFWDWXlOD/AM8pEwcfQEf98ipS5oWRUpa3Py8/aZ+Fl54O8e3GtWtsyWOpTMXYD5Y7kffX23Y3D6n0r5nEw5JN2PrMsr88VAX4f6vdx2UcVyxdQMZ9q86Tuz6mhP3bHYXNja3y+akgU4rNzSOiUVJHM6rpQiQsSWXtTU00c0qTTOS1C2Vc/IKlSb0MmmmY8rkHaRxTUepDRBtGdxHNNuyIcWiVZMYwBVakkgkZhjbxmlzWYivM6R5Zhj+dJtPUdilcX2xSxG1QOaavLYHoewfBz4E3PiaSDxV44tXt9MBElpYSDD3Po8g6qnoOrfTr3YbDOrq9jxcwzJUVyU9z6fHlRwR2kEaxwxAKqquBgdAAO1exGChGyPk5VJVZXZm3UpF4IzngdPSnZPco+vdDs4dP0mCwg2Ay5YheyDivZpw5Y2OecjwD4sakbvxDdRKcrHlFrmqvWy3BO+p6T4J1S/stM8P6ZbQRskqRpO8jcJGFAIxkcn17dxVQk7JWuXLc5b4y/Crw58R7G90+WNBPMu2a3dghYj7rq38LDs3T1rlxVCNTodeFxTpS03PiW++E/j/4b61daXfeGtQu9PjZjFeW9s0qmMfxNsB2/jx6EivmK+GnTb0Pt8vzKlVjaT1FF5DszG+0jqK86a5T3YSjJXiZt/eKwK7ue9ZyYpPsc7dJHMSWGc9OKqNWyIaVjPl0qJn4Xt6VTq3Rm4q5A+kLjhelPnYnTQiaOCcE03Ub3RHsluidtJ2KDj8azbb1QeyXUtaX8OvFPiWXy/Dnh6/1Jidv7iBmUH0LfdX8SK2p809InPWrUqSvNnr3wy/Z4t9BuI9c+IEEF1qqENBpqsssFoR3kIysknTgfKvuenr4XAtu8vuPmcxzVSi4Uj2gCMMI0O5+/tXswhyK1j5eU3N+8xsTLJOyr91ByfeqS7oqL5dDFvzO+pYgcK2OSVz2pXka77n2No16L23v9ZUBYkjZYV7BRnp+FewrdDkku58y+Kbtr3XppSD88xwPQZrz6mr0KWx6zoXmNplnJCOYwBgdj61vTl7tkVoy94z059d0warpkzQ6laggOp5P19QadSKkrpCa8zzvRNfl1a8OkaheTWmoW4ztU5EpHXbmuCrT507aM66NeUXZnlPxL+FD65q13cSCG0u2y8E8MW3zeOsuPvc98A149fBe0fvaM93CZrWw73vE+fPEWha74aujaa7YyW7EkJL1jlHqrdD/AD9a8WvQnSdpI+qw2PpYhXhJGUqIQAD9K5+VJ6nWpc2xIqxRkhhQ/IrmvsiOTDcgAA009NyRHlt4IxJIwAHerUbqzYXseq/Bf4Tf8Jj5PjLxlNFpnhdGP2VJnYS6nKpwVjVAW8sEHc2ME8A9cdmFwLrNPWx4OZ5mqC5aerPdhq8trZxaJodta6Xp9sjRolohj+U9ST6nueK+ho4aNNWSsj4/EY6dV+87swrq8zKLOwX94eCR/CK6VCMTzXUlN6lhgLG38kOWlf7x71UtNyrdx0Ki2tjkjc3J9qm/RFpW1MmBTPqDnrwalO70Dmuf/9k=",examdate, 'https://sarathi.parivahan.gov.in/sarathiWS/rsServices/ServicesOnLLProctor/getOnlineLltestProcterDatasave',10,"/randomPhotoSyncAPI",{"examCode": "102", "subCode": "1001", "eNo":"3876139021", "slotId":slotId}).then(function () {
		    	 aware.startProcess();
		    	/* setTimeout(() => {
			         aware.endProcess();
			     }, 6000) */
				
			     $("#camText").hide();
		    	 document.getElementById("stallexam").src = "stallexamaction.do";	
		    	 
		    	});
		}
		else
		{
			document.getElementById("stallexam").src = "stallexamaction.do";
		}

}
</script>
<!-- <body onload="loadTimer()"></body> -->
</html>