
// Sarathi Anugnya Auto-Reload & Pause Script

(function() {
    'use strict';

    let hasReloaded = false;
    let isPaused = false;
    let observer = null;

    console.log('🚀 Sarathi Script Started');

    function isErrorPage() {
        const url = window.location.href;
        return url.includes('403.jsp') || url.includes('404.jsp');
    }

    function reloadToAnugnya() {
        if (!hasReloaded) {
            hasReloaded = true;
            console.log('🔄 Redirecting to Anugnya page...');
            window.location.href = 'https://sarathi.parivahan.gov.in/sarathiservice/authenticationaction.do?authtype=Anugnya';
        }
    }

    function pausePage() {
        if (!isPaused) {
            isPaused = true;
            window.stop();
            if (observer) {
                observer.disconnect();
                observer = null;
            }
            console.log('⏸️ Page paused - LL inputs detected');
            alert('✅ Page paused. Captcha & LL input ready.');
        }
    }

    function checkForInputs() {
        const applNumberInput = document.querySelector('input[name="applNumber"]');
        const captchaInput = document.querySelector('input[name="captcha"]');
        if (applNumberInput && captchaInput) {
            console.log('✅ Both inputs found:', { applNumber: applNumberInput, captcha: captchaInput });
            pausePage();
            return true;
        }
        return false;
    }

    function init() {
        if (isErrorPage()) {
            console.log('❌ Error page detected:', window.location.href);
            window.stop();
            document.documentElement.innerHTML = '';
            setTimeout(reloadToAnugnya, 100);
            return;
        }

        if (window.location.href.includes('authtype=Anugnya')) {
            console.log('📍 On Anugnya page, monitoring for inputs...');
            if (document.readyState !== 'loading') {
                if (checkForInputs()) return;
            }

            observer = new MutationObserver(function(mutations) {
                if (isPaused) return;
                for (let mutation of mutations) {
                    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                        if (checkForInputs()) return;
                    }
                }
            });

            observer.observe(document, { childList: true, subtree: true });

            document.addEventListener('DOMContentLoaded', function() {
                if (!isPaused) checkForInputs();
            });

            window.addEventListener('load', function() {
                if (!isPaused) checkForInputs();
            });
        }
    }

    let currentUrl = window.location.href;
    setInterval(function() {
        if (window.location.href !== currentUrl) {
            currentUrl = window.location.href;
            hasReloaded = false;
            isPaused = false;
            if (observer) {
                observer.disconnect();
                observer = null;
            }
            console.log('🔄 URL changed, reinitializing...');
            setTimeout(init, 100);
        }
    }, 500);

    init();
})();
