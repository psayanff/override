// ================= inject.js =================
(function () {
    console.log("🚀 Injected bypass script on:", window.location.href);

    // === 1. Disable Reload Detection ===
    try {
        Object.defineProperty(performance, "getEntriesByType", {
            value: () => [{ type: "navigate" }]
        });
        console.log("✅ Bypassed reload detection");
    } catch (e) {
        console.log("⚠️ Reload detection already bypassed or not supported.");
    }

    // === 2. Disable Tab Visibility Forced Reload ===
    document.addEventListener("visibilitychange", function (e) {
        e.stopImmediatePropagation();
        console.log("✅ Blocked forced reload on tab visibility change");
    }, true);

    // === 3. Prevent Window Close on Navigation Check ===
    window.close = function () {
        console.log("✅ Blocked forced window.close()");
    };

    // === 4. Allow Seamless Continue Click ===
    const submBtn = document.querySelector("#subm");
    if (submBtn) {
        submBtn.addEventListener("click", function () {
            console.log("▶️ Continue button clicked → Going to next step…");
        });
    } else {
        console.log("⚠️ #subm button not found yet");
    }
})();
