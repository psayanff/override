
document.addEventListener('DOMContentLoaded', function () {
  const btn = document.getElementById('runbtn');
  btn.addEventListener('click', () => {
    localStorage.setItem('autoFlowMode', 'true');
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        function: () => {
          localStorage.setItem('autoFlowMode', 'true');
          location.reload();
        }
      });
    });
  });
});
